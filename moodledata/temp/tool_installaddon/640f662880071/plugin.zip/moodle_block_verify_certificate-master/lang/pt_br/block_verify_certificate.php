<?php
$string['title'] = 'Verificar Certificados';
$string['pluginname'] = 'Verificar Certificados';
$string['certificate'] = 'Verificação do código de certificado:';
$string['verifycertificate'] = 'Verificar Certificado';
$string['notfound'] = 'O número do certificado não pode ser validadado.';
$string['to'] = 'Emitido para';
$string['course'] = 'Curso';
$string['date'] = 'Data';
$string['grade'] = 'Nota';
$string['customtext'] = 'Programa do curso';
$string['enrol_period'] = 'Período de realização';
$string['printhours'] = 'Carga horária';
$string['chooseprofilefields'] = 'Escolha os campos de perfil para mostrar';
$string['nofields'] = 'Nenhum campo de perfil definido';
