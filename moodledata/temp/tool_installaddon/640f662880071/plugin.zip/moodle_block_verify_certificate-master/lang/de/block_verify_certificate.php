<?php
$string['title'] = 'Zertifikate verifizieren';

$string['certificate'] = 'Abgleichung des Zertifikat-Codes:';
$string['verifycertificate'] = 'Zertifikate verifizieren';
$string['notfound'] = 'Die Zertifikatsnummer konnte nicht bestätigt werden.';
$string['to'] = 'Zuerkannt';
$string['course'] = 'Kurs';
$string['date'] = 'Am';
$string['grade'] = 'Bewertung';
$string['customtext'] = 'Kurs details';
$string['enrol_period'] = 'Einschreiben Zeitraum';
$string['printhours'] = 'Stunden';
$string['chooseprofilefields'] = 'Wählen Sie Profilfelder angezeigt';
$string['nofields'] = 'Kein ProfilFeld definiert';
