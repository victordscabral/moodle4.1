Release Notes

Release 3.8.0 (Build 2019112600)
Updated subplugin declaration file to new subplugins.json structure.

(see CHANGES.TXT in release 3.3 for earlier changes.)