moodle_report_messages
======================

A simple report to view message exchanges between user from a course

To install, clone this plugin in $MOODLE/report/messages folder:
  $ cd $MOODLE/report
  $ git clone https://github.com/interlegis/moodle_report_messages.git messages

Enter in your moodle site as admin user and install the plugin

Usage:
  In a course, click in Administration > Report > Messages report to see a
  synthesis report for all enrolled users. Click in {view details} link to
  see all messages sended from/to that user.
