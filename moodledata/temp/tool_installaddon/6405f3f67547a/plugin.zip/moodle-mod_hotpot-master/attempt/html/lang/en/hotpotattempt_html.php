<?php
$string['pluginname'] = 'HTML output formats';
$string['privacy:metadata'] = 'The HTML output formats module does not store any personal data.';
