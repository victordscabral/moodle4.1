<?php
$string['pluginname'] = 'Overview report';
$string['privacy:metadata'] = 'The overview report module does not store any personal data.';
