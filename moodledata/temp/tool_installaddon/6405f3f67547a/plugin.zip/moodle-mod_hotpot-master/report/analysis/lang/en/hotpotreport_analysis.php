<?php
$string['pluginname'] = 'Statistical analysis report';
$string['privacy:metadata'] = 'The statistical analysis report module does not store any personal data.';
