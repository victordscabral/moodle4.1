<?php
$string['pluginname'] = 'Scores report';
$string['privacy:metadata'] = 'The scores report module does not store any personal data.';
