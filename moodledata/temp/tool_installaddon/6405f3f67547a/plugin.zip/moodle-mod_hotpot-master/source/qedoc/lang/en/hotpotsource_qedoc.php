<?php
$string['pluginname'] = 'Qedoc source files';
$string['privacy:metadata'] = 'The Qedoc source files module does not store any personal data.';
