The questionnaire module allows you to construct questionnaires (surveys) from a
variety of question type. It was originally based on phpESP, and Open Source
survey tool.

--------------------------------------------------------------------------------
Developers Note:

There is no main branch. Questionnaire is maintained in MOODLE_XX_STABLE
branches. Use the latest STABLE branch for development or installation.
The current stable branch is MOODLE_400_STABLE, and supports Moodle 4.0 and up.
Use the MOODLE_311_STABLE branch for Moodle 3.9 through 3.11.

--------------------------------------------------------------------------------
To Install:

1. Load the questionnaire module directory into your "mod" subdirectory.
2. Visit your admin page to create all of the necessary data tables.

--------------------------------------------------------------------------------
To Upgrade:

1. Copy all of the files into your 'mod/questionnaire' directory.
2. Visit your admin page. The database will be updated.

--------------------------------------------------------------------------------
Please read the CHANGES.md file for more info about successive changes
