moodle_certificates
===================

Certificados Moodle personalizados para o Interlegis.

Para instalar, siga os passos:

1. Instale o Módulo padrão de certificados Moodle (https://moodle.org/plugins/view.php?plugin=mod_certificate);
2. Clone este repositório em um diretório temporário;
3. Copie todas os subdiretórios deste repositório para <moodle_dir>/mod/certificate.
