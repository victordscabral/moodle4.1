# Installation
Copy the content of the repository into theme/boost_o365teams directory.
Follow https://docs.moodle.org/35/en/Installing_plugins#Installing_manually_at_the_server .
